# Charleston County, SC — Motivated Seller Lead Scraper

Automated daily pipeline that pulls motivated-seller leads from the
**Charleston County Register of Deeds (ROD)** and enriches them with
owner / site / mailing addresses from the county's **ArcGIS parcel API**.
Results feed a GitHub Pages dashboard and an optional GoHighLevel CSV export.

---

## ⚠️ Legal Notices — Read First

### SC Code § 30-2-50 — Commercial Solicitation Restriction

> Section 30-2-50(A) of the SC Code of Laws prohibits a person or private
> entity from obtaining or using any **personal information** obtained from the
> public records of a public body such as the County of Charleston **for
> purposes of commercial solicitation directed to any person in the state of
> South Carolina.**

> Section 30-2-50(D): knowing violation is a **misdemeanor** — fine up to $500
> and/or up to one year imprisonment.

Before running any direct-mail or cold-call campaign from this data, consult
a licensed South Carolina attorney.

### SC Judicial Public Index — Automated Scraping Prohibited

The South Carolina Judicial Department explicitly prohibits automated scraping
of `publicindex.sccourts.org`. Accordingly, the following record types are
**NOT** collected by this tool and must be obtained manually or through a
licensed data provider:

| Record type | Why excluded |
|---|---|
| Judgments (JUD / CCJ / DRJUD) | SC Judicial Public Index — scraping prohibited |
| Probate records (PRO) | Probate Court — separate judicial system |
| Notice of Foreclosure | SC is a judicial-foreclosure state; the complaint is filed in court, not ROD. **Lis Pendens (LP)** filed in the ROD is the correct pre-foreclosure signal. |

---

## What This Tool Collects

| Code | Label | System | Notes |
|---|---|---|---|
| LP | Lis Pendens | ROD — DM | Pre-foreclosure signal in SC |
| RELLP | Release of Lis Pendens | ROD — DM | Case resolved or refinanced |
| TAXDEED | Tax Deed | ROD — DM | County sold property for unpaid taxes |
| NOC | Notice of Commencement | ROD — DM | Construction started; useful for NOC leads |
| LNMECH | Mechanic's Lien | ROD — DM | Contractor / sub unpaid |
| LNHOA | HOA Lien | ROD — DM | Delinquent HOA dues |
| MEDLN | Medicaid Lien | ROD — DM | State recovery lien |
| LN | General Lien | ROD — DM | Catch-all lien type |
| LNIRS | IRS / Federal Tax Lien | ROD — FL | IRS debt attached to property |
| LNFED | Federal Lien | ROD — FL | Other federal agency liens |
| LNCORPTX | State / Corp Tax Lien | ROD — FL | SC DOR corporate/individual tax liens |

---

## Data Sources

| Source | URL | Method |
|---|---|---|
| ROD Day Book | `roddaybook.charlestoncounty.org` | Playwright |
| ROD DM Type+Date | `charlestoncounty.gov/departments/rod/ds-DMTypeAndDate.php` | Playwright |
| ROD FL Type+Date | `charlestoncounty.gov/departments/rod/ds-FLTypeandDate.php` | Playwright |
| Parcel enrichment | `gisccapps.charlestoncounty.org/arcgis/rest/services/GIS_VIEWER/Parcel_Search/MapServer/4/query` | requests JSON |

> **Note on Day Book:** As of November 3, 2025, the ROD Day Book only exposes
> **today's** recordings — it no longer supports historical date lookback. The
> DM and FL Type+Date searches cover the full `LOOKBACK_DAYS` window.

> **Note on DBF:** Charleston County does **not** publish a bulk parcel DBF
> (common in Florida). Parcel enrichment is done via the live ArcGIS REST API,
> queried by owner name for each lead.

---

## Seller Score (0–100)

```
Base:               30
+ per flag:         +10 each
+ LP + tax combo:   +20  (Lis Pendens AND tax lien on same owner)
+ amount > $100k:   +15
+ amount > $50k:    +10  (mutually exclusive with above)
+ filed ≤ 7 days:   +5
+ has address:      +5
Cap:                100
```

**Flags:** Lis pendens · Tax deed · Tax lien · Mechanic lien · HOA lien ·
Medicaid lien · LLC / corp owner · New this week · LP+FC combo

---

## Repo Structure

```
.
├── scraper/
│   ├── fetch.py          # Main pipeline (all scrapers + enrichment)
│   └── requirements.txt
├── dashboard/
│   ├── index.html        # GitHub Pages dashboard
│   └── records.json      # Output — committed daily by CI
├── data/
│   └── records.json      # Archive copy
│   └── leads_ghl_YYYYMMDD.csv   # GHL export (optional)
├── .github/
│   └── workflows/
│       └── scrape.yml    # Daily CI job
└── README.md
```

---

## GitHub Setup (one-time)

### 1. Create the repo and push

```bash
git init
git remote add origin https://github.com/YOUR_ORG/YOUR_REPO.git
git add .
git commit -m "init: Charleston County lead scraper"
git push -u origin main
```

### 2. Enable GitHub Pages

Settings → Pages → Build and deployment → **Source: GitHub Actions**

### 3. Set Actions write permissions

Settings → Actions → General → Workflow permissions →
**Read and write permissions** ✓

### 4. Verify the first run

Actions → *Charleston County Lead Scraper* → **Run workflow**

The pipeline will:
1. Scrape the ROD Day Book for today's filings
2. Search each DM document type for the past 7 days
3. Search State, Federal, and UCC liens for the past 7 days
4. Enrich each lead's owner name against the ArcGIS parcel layer
5. Compute flags and seller scores
6. Commit `dashboard/records.json` + `data/records.json`
7. Deploy `dashboard/` to GitHub Pages

---

## Local Development

```bash
# Clone and set up environment
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r scraper/requirements.txt
python -m playwright install --with-deps chromium

# Run with browser visible (to debug form selectors)
python scraper/fetch.py --lookback 7 --headless 0

# 14-day lookback, write GHL CSV
python scraper/fetch.py --lookback 14 --export-ghl

# Outputs:
#   dashboard/records.json
#   data/records.json
#   data/leads_ghl_YYYYMMDD.csv   (if --export-ghl)
```

---

## Calibrating the ROD Instrument Type Codes

The ROD's DM search takes a short instrument-type code (e.g. `LP` for Lis
Pendens, `ML` for Mechanic's Lien). The exact codes the portal accepts are
not published. **On first run, open a browser (`--headless 0`) and:**

1. Navigate to `https://www.charlestoncounty.gov/departments/rod/ds-DMTypeAndDate.php`
2. Click into the Instrument Type field — some portals show a dropdown or
   autocomplete list of valid codes.
3. Enter a known code (e.g. `LP`) and a recent date range; verify results appear.
4. Update the `codes` list in `DOC_SPECS` in `scraper/fetch.py` with the
   confirmed codes.

The current codes in `DOC_SPECS` are the most common across SC county portals
and will be logged at runtime so you can see which ones returned data.

---

## GHL (GoHighLevel) CSV Export

Run with `--export-ghl` (or set `export_ghl: true` in the workflow dispatch):

| Column | Notes |
|---|---|
| First Name / Last Name | Split from Grantor/Maker name |
| Mailing Address … Zip | From ArcGIS parcel lookup |
| Property Address … Zip | Site address from ArcGIS |
| Lead Type | Human label (e.g. "Lis Pendens") |
| Document Type | Raw ROD instrument code |
| Date Filed | YYYY-MM-DD |
| Document Number | Book-Page or doc # from ROD |
| Amount/Debt Owed | Dollar amount if available |
| Seller Score | 0–100 |
| Motivated Seller Flags | Semicolon-separated |
| Source | "Charleston County, SC Register of Deeds" |
| Public Records URL | Direct link to ROD doc viewer |

---

## Dashboard

The GitHub Pages dashboard (`dashboard/index.html`) provides:

- **Summary stats** — total leads, with-address count, high-priority count, new this week
- **Sort** — click any column header
- **Filters** — full-text search · doc type · flag · min score · source
- **Score badges** — green ≥70 · amber ≥50 · grey otherwise
- **Flag colour coding** — yellow = Lis Pendens · red = LP+FC · purple = Tax lien · green = Mechanic · blue = HOA · pink = Probate
- **CSV export** — one-click export of current filtered view
- **Direct ROD link** — "view ↗" opens the document image in the county viewer

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| Day Book shows 0 results | Day Book only shows **today** — run after 7:30 AM ET when ROD opens |
| DM search returns 0 for LP | Verify the code (`LP` vs `LIS PEN`) by visiting the URL with `--headless 0` |
| ArcGIS enrichment returns nothing | The parcel field names may differ; check the layer at `gisccapps.charlestoncounty.org/arcgis/rest/services/GIS_VIEWER/Parcel_Search/MapServer/4?f=json` |
| Playwright timeout | ROD portal is slow; increase `HTTP_TIMEOUT` and Playwright default timeout in `fetch.py` |
| GitHub Actions fails to push | Ensure Settings → Actions → **Read and write permissions** is enabled |
